/*
  Author: Vadim Balan
  Date: 5/28/2021
  Version: This is the security configuration file that configures what places have access by which roles
 */
package edu.greenriver.sdev.booklending.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.*;
import org.springframework.security.config.annotation.web.configuration.*;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter
{
    private final UserDetailsService service;

    /**
     * This is the constructor for this class
     * @param service takes in a service with userdetails
     */
    public SecurityConfiguration(UserDetailsService service)
    {
        this.service = service;
    }

    /**
     * This method encrypts the password
     * @return encrypted password
     */
    @Bean
    public BCryptPasswordEncoder passwordEncoder()
    {
        return new BCryptPasswordEncoder();
    }

    @Override
    public void configure(AuthenticationManagerBuilder auth) throws Exception
    {
        BCryptPasswordEncoder encoder = passwordEncoder();
        auth
                .userDetailsService(service)
                .passwordEncoder(encoder);
    }

    @Override
    public void configure(WebSecurity web) throws Exception
    {
        // do not restrict access to our javascript/css files
        // or access to the h2-console
        web
                .ignoring().antMatchers("/js/**")
                .and()
                .ignoring().antMatchers("/css/**")
                .and()
                .ignoring().antMatchers("/h2-console/**");
    }

    @Override
    public void configure(HttpSecurity http) throws Exception
    {
        http
                .authorizeRequests()
                    .antMatchers("/books/all").hasAuthority("ROLE_ADMIN")
                    .antMatchers("/lenders/**").hasAuthority("ROLE_USER")
                    .antMatchers("/books/**").hasAuthority("ROLE_USER")
                    .antMatchers("/**").permitAll()
                .and()
                .formLogin()
                    .permitAll()
                    .loginPage("/login")
                    .defaultSuccessUrl("/")
                    .failureUrl("/login?error=true")
                .and()
                .exceptionHandling()
                    .accessDeniedPage("/access_denied")
                .and()
                .logout()
                    .permitAll()
                    .logoutUrl("/logout")
                    .logoutSuccessUrl("/login?logout=true");
    }


}
