/*
  Author: Vadim Balan
  Date: 5/11/2021
  Version: 1.0 This is the Lender that has all the parts of a lender and what makes a lender
 */
package edu.greenriver.sdev.booklending.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Lender implements UserDetails
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String username;
    private String password;

    @Transient      // Don't persist this field
    private String passwordConfirmed;

    private String firstName;
    private String lastName;

    @Lob
    private String bio;

    // Permissions for the user
    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "lender")
    private Collection<Authority> authorities = new HashSet<>();

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "owner")
    private List<Book> books = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "borrower")
    private List<Book> borrowedBooks = new ArrayList<>();

    @Override
    public boolean isAccountNonExpired()
    {
        return true;
    }

    @Override
    public boolean isAccountNonLocked()
    {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired()
    {
        return true;
    }

    @Override
    public boolean isEnabled()
    {
        return true;
    }
}
