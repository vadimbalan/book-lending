/*
  Author: Vadim Balan
  Date: 4/21/2021
  Version: 1.0 This is the indexController that is in control of the index page
 */
package edu.greenriver.sdev.booklending.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController extends AuthenticationInformation
{
    /**
     * This is the mapping for the index page
     * @return this returns the index.html file
     */
    @RequestMapping(path = {"", "/", "index", "index.html"})
    public String mainPage()
    {
        return "index.html";
    }
}
