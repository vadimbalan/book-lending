/*
  Author: Vadim Balan
  Date: 5/28/2021
  Version: This is the authentication information file that checks if user is logged in and who is logged in
 */
package edu.greenriver.sdev.booklending.controllers;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.ModelAttribute;

public class AuthenticationInformation
{
    /**
     * This checks if user is logged in
     * @return a true false if user is logged in
     */
    @ModelAttribute("validUserLoggedIn")
    public boolean isLoggedIn()
    {
        Authentication auth = SecurityContextHolder
                .getContext()
                .getAuthentication();
        return auth != null && auth.isAuthenticated() && !(auth instanceof AnonymousAuthenticationToken);
    }

    /**
     * Gets the name of the user that is logged in
     * @return a string of the username
     */
    @ModelAttribute("loggedInUsername")
    public String loggedInUsername()
    {
        return SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getName();
    }
}
