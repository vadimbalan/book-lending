/*
  Author: Vadim Balan
  Date: 5/18/2021
  Version: 1.0 This is the AuthenticationController that is in charge for when someone signs up
 */
package edu.greenriver.sdev.booklending.controllers;

import edu.greenriver.sdev.booklending.model.Lender;
import edu.greenriver.sdev.booklending.services.LenderService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthenticationController extends AuthenticationInformation
{
    private LenderService service;

    /**
     * This is the controller for this class
     * @param service this is the lender service repo
     */
    public AuthenticationController(LenderService service)
    {
        this.service = service;
    }

    /**
     * This is the /register controller link
     * @param model this is the model that helps
     * @return this returns the register form html file
     */
    @GetMapping("/register")
    public String register(Model model)
    {
        model.addAttribute("lender", new Lender());
        return "/general/register";
    }

    /**
     * This is where the data posts
     * @param lender this is the lender class
     * @param model this is the model class that is used to get stuff out to the html page
     * @return this redirects either to the lenders/all or back to the page with an error
     */
    @PostMapping("/register")
    public String register(@ModelAttribute Lender lender, Model model)
    {
        // Register the new user
        lender = service.registerUser(lender);

        if (lender != null)
        {
            return "redirect:/lenders/all";
        }
        else
        {
            model.addAttribute("errors", "Passwords do not match!");
            return "/general/register";
        }
    }

    /**
     *
     * @param error if the values enter give an error
     * @param logout if the user clicks logout then it logs them out
     * @param model this is used to take information and add to the html files
     * @return this login page
     */
    @GetMapping("/login")
    public String login(@RequestParam(required = false) String error,
                        @RequestParam(required = false) String logout,
                        Model model)
    {
        if (error != null)
        {
            model.addAttribute("message", "Invalid credentials");
        }

        if (logout != null)
        {
            model.addAttribute("message", "User logged out");
        }

        return "/general/login";
    }

    /**
     * This is the access denied page
     * @return a html page with access denied
     */
    @GetMapping("/access_denied")
    public String denied()
    {
        return "/general/access_denied";
    }
}
