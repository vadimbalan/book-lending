/*
  Author: Vadim Balan
  Date: 5/11/2021
  Version: 1.0 This is the IBookRepository that is the interface of the book (CRUD)
 */
package edu.greenriver.sdev.booklending.repositories;

import edu.greenriver.sdev.booklending.model.Book;
import edu.greenriver.sdev.booklending.model.Lender;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

/**
 * This it the interface for the book repository
 */
public interface IBookRepository extends CrudRepository<Book, Long>
{
    Optional<Book> getBookByIsbn(String isbn);

    boolean existsDistinctByIsbn(String isbn);

    List<Book> getAllByOwner(Lender lender);

    List<Book> getAllByOwnerAndBorrowerIsNull(Lender lender);

    List<Book> getAllByOwnerAndBorrowerIsNotNull(Lender lender);

    List<Book> getAllByBorrower(Lender lender);
}
