/**
 * Author: Vadim Balan
 * Date: 4/21/2021
 * Version: 1.0 This is the main class file that runs the website
 */
package edu.greenriver.sdev.booklending;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookLendingApplication
{

    public static void main(String[] args)
    {
        SpringApplication.run(BookLendingApplication.class, args);
    }

}
