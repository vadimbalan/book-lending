/*
  Author: Vadim Balan
  Date: 5/28/2021
  Version: This is the authority class that adds the different roles
 */
package edu.greenriver.sdev.booklending.model;

import lombok.*;
import org.springframework.security.core.GrantedAuthority;

import javax.persistence.*;

@Entity
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Authority implements GrantedAuthority
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String authority;

    @ManyToOne
    private Lender lender;
}
