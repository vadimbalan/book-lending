/*
  Author: Vadim Balan
  Date: 5/11/2021
  Version: 1.0 This is the ILenderRepository that is the interface of the Lenders using CRUD
 */
package edu.greenriver.sdev.booklending.repositories;

import edu.greenriver.sdev.booklending.model.Lender;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

/**
 * This it the interface for the lender repository
 */
public interface ILenderRepository extends CrudRepository<Lender, Long>
{
    Optional<Lender> getLenderByUsername(String username);
}
