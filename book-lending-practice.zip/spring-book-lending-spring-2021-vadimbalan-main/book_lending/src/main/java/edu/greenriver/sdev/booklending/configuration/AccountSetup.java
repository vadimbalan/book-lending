/*
  Author: Vadim Balan
  Date: 5/28/2021
  Version: This is the account setup page which sets up an account with a role
 */
package edu.greenriver.sdev.booklending.configuration;

import edu.greenriver.sdev.booklending.model.Authority;
import edu.greenriver.sdev.booklending.model.Lender;
import edu.greenriver.sdev.booklending.repositories.ILenderRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashSet;

@Component
public class AccountSetup implements CommandLineRunner
{
    private ILenderRepository repo;

    public AccountSetup(ILenderRepository repo)
    {
        this.repo = repo;
    }

    @Override
    public void run(String... args) throws Exception
    {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

        Lender admin = Lender.builder()
                .username("admin")
                .password(encoder.encode("password"))
                .authorities(new HashSet<>())
                .build();

        admin.getAuthorities().addAll(Arrays.asList(
                Authority.builder()
                        .authority("ROLE_ADMIN")
                        .lender(admin)
                        .build(),
                Authority.builder()
                        .authority("ROLE_USER")
                        .lender(admin)
                        .build()
        ));
        repo.save(admin);

    }
}
