/*
  Author: Vadim Balan
  Date: 4/21/2021
  Version: 1.0 This is the LenderController that is in charge of the lenders page and all lenders
 */
package edu.greenriver.sdev.booklending.controllers;

import edu.greenriver.sdev.booklending.model.Lender;
import edu.greenriver.sdev.booklending.services.LenderService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/lenders")
public class LenderController extends AuthenticationInformation
{
    private final LenderService service;

    /**
     * This is the constructor for the lender controller
     * @param service this is the lender service
     */
    public LenderController(LenderService service)
    {
        this.service = service;
    }

    /**
     * This is the mapping for the /all page
     * @param model this is used to add things to the model so it can be displayed on the html file
     * @return the all lenders page with a list of all the lenders that are signed up
     */
    @GetMapping("/all")
    public String allLenders(Model model)
    {
        model.addAttribute("lenders", service.getLenders());
        return "lenders/all_lenders";
    }

    /**
     * This shows a page of the individual username
     * @param username this is a lenders username
     * @param model this is used to add things to the model so it can be displayed on the html file
     * @return this returns the lenders by the username page
     */
    @GetMapping("/username/{username}")
    public String lenderByUsername(@PathVariable String username, Model model)
    {
        Lender lender = service.getLoggedInUser();

        model.addAttribute("booksToLend", service.getBooksToLoan(lender));
        model.addAttribute("loanedBooks", service.getLoanedBooks(lender));
        model.addAttribute("borrowedBooks", service.getBorrowedBooks(lender));

        model.addAttribute("lender", service.getLender(username));
        return "lenders/lenders_by_username";
    }

    /**
     * This returns the list of books used by the user
     * @param model this is used to write to the html file
     * @return a html file of the books
     */
    @GetMapping("/mybooks")
    public String myBooks(Model model)
    {
        Lender lender = service.getLoggedInUser();
        model.addAttribute("books", service.getBooksByLender(lender));
        return "/general/my_books";
    }
}
