/*
  Author: Vadim Balan
  Date: 5/11/2021
  Version: 1.0 This is the BookService that is in charge of returning parts of a book
 */
package edu.greenriver.sdev.booklending.services;

import edu.greenriver.sdev.booklending.model.Book;
import edu.greenriver.sdev.booklending.model.Lender;
import edu.greenriver.sdev.booklending.repositories.IBookRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class BookService
{
    private final IBookRepository bookRepository;

    /**
     * This is the constructor for the book service
     * @param bookRepository takes in a book repository interface
     */
    public BookService(IBookRepository bookRepository)
    {
        this.bookRepository = bookRepository;
    }

    /**
     * This iterates over the books
     * @return the book
     */
    public Iterable<Book> getBooks()
    {
        return bookRepository.findAll();
    }

    /**
     * This gets the book by the ISBN
     * @param isbn takes in a string of the isbn
     * @return the book that has that isbn in the database
     */
    public Book getBook(String isbn)
    {
        return bookRepository.getBookByIsbn(isbn).orElse(null);
    }

    /**
     * This is used to add a new book
     * @param book takes in the book class with all fields
     * @return the book being saved
     */
    public Book addNewBook(Book book)
    {
        if(!bookRepository.existsDistinctByIsbn(book.getIsbn()))
        {
            return bookRepository.save(book);
        }
        else
        {
            return null;
        }
    }

    /**
     * This returns a boolean if the book is saved
     * @param book takes in a book class
     * @param file also takes in an image class
     * @return true or false if the book is saved
     * @throws IOException throws an exception if the file is wrong
     */
    public boolean saveBook(Book book, Lender loggedInUser, MultipartFile file) throws IOException
    {
        if (getBook(book.getIsbn()) == null)
        {
            // Link book and logged in user
            book.setOwner(loggedInUser);
            loggedInUser.getBooks().add(book);

            saveImageToBook(book, file);
            bookRepository.save(book);
            return true;
        }
        return false;
    }

    /**
     * This is used to save the image to a book
     * @param book this is the book class
     * @param file this is the image file
     * @throws IOException if the file is wrong
     */
    private void saveImageToBook(Book book, MultipartFile file) throws IOException
    {
        byte[] fileBytes = file.getBytes();
        Byte[] bytes = new Byte[fileBytes.length];

        for (int i = 0; i < fileBytes.length; i++)
        {
            bytes[i] = fileBytes[i];
        }

        book.setCoverImage(bytes);
    }
}
