/*
  Author: Vadim Balan
  Date: 5/11/2021
  Version: 1.0 This is the LenderService that is in charge of returning parts of a lender
 */
package edu.greenriver.sdev.booklending.services;

import edu.greenriver.sdev.booklending.model.Authority;
import edu.greenriver.sdev.booklending.model.Book;
import edu.greenriver.sdev.booklending.model.Lender;
import edu.greenriver.sdev.booklending.repositories.IBookRepository;
import edu.greenriver.sdev.booklending.repositories.ILenderRepository;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LenderService implements UserDetailsService
{
    private final ILenderRepository lenderRepository;
    private IBookRepository bookRepository;



    /**
     * This is the lender service constructor
     * @param lenderRepository takes in the lender repository
     */
    public LenderService(ILenderRepository lenderRepository, IBookRepository bookRepository)
    {
        this.lenderRepository = lenderRepository;
        this.bookRepository = bookRepository;
    }

    /**
     * This iterates over all the lenders
     * @return a lender
     */
    public Iterable<Lender> getLenders()
    {
        return lenderRepository.findAll();
    }

    /**
     * This method returns a lender by the username of the lender
     * @param username takes in a username that is created by the lender
     * @return a lender that has that username
     */
    public Lender getLender(String username)
    {
        return lenderRepository.getLenderByUsername(username).orElse(null);
    }

    /**
     * This registers a user once they sign up
     * @param lender saves information to the lender class
     * @return the information being saved
     */
    public Lender registerUser(Lender lender)
    {
        // if Passwords match
        if(lender.getPassword().equals(lender.getPasswordConfirmed()))
        {
            // encode the password
            lender.setPassword(new BCryptPasswordEncoder()
                    .encode(lender.getPassword()));

            // save the role of user for the new account
            Authority authority = Authority
                    .builder()
                    .authority("ROLE_USER")
                    .lender(lender)
                    .build();
            lender.getAuthorities().add(authority);

            // Save and return
            return lenderRepository.save(lender);
        }
        else
        {
            return null;
        }
    }

    /**
     * This loads the user by the username
     * @param username takes in the username of the user
     * @return the lender
     * @throws UsernameNotFoundException if username or password is incorrect
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException
    {
        // This matches our password using Spring Security
        Optional<Lender> lender = lenderRepository.getLenderByUsername(username);

        if (lender.isPresent())
        {
            return lender.get();
        }
        else
        {
            throw new UsernameNotFoundException("Username or password is incorrect");
        }
    }

    /**
     * Returns the lender of the logged in user
     * @return a logged in user which is a lender
     */
    public Lender getLoggedInUser()
    {
        Authentication auth = SecurityContextHolder
                .getContext()
                .getAuthentication();

        String username = auth.getName();
        Lender loggedInUser = lenderRepository
                .getLenderByUsername(username)
                .orElse(null);

        return loggedInUser;
    }

    /**
     * This is a list of the books by the lender
     * @param lender takes in the lender
     * @return a list of all the books by the owner (lender owner)
     */
    public List<Book> getBooksByLender(Lender lender)
    {
        return bookRepository.getAllByOwner(lender);
    }

    /**
     * returns all books that are owned by the lender and not borrowed
     * @param lender takes the lender class
     * @return books to loan
     */
    public List<Book> getBooksToLoan(Lender lender)
    {
        return bookRepository.getAllByOwnerAndBorrowerIsNull(lender);
    }

    /**
     * Returns all books that are owned by the lender and are borrowed
     * @param lender
     * @return
     */
    public List<Book> getLoanedBooks(Lender lender)
    {
        return bookRepository.getAllByOwnerAndBorrowerIsNotNull(lender);
    }

    /**
     * Returns all books borrowed by the lender
     * @param lender
     * @return
     */
    public List<Book> getBorrowedBooks(Lender lender)
    {
        return bookRepository.getAllByBorrower(lender);
    }

    public void borrowBook(Lender lender, Book book)
    {
        // only borrow books that aren't in use
        if (book.getBorrower() == null)
        {
            lender.getBorrowedBooks().add(book);
            book.setBorrower(lender);

            lenderRepository.save(lender);
            bookRepository.save(book);
        }
    }
}
