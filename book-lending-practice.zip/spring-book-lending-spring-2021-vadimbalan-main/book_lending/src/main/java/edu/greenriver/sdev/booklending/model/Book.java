/*
  Author: Vadim Balan
  Date: 5/11/2021
  Version: 1.0 This is the Book that has all the methods and parts of a book
 */
package edu.greenriver.sdev.booklending.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.core.io.ClassPathResource;

import javax.persistence.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Book
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String isbn;
    private String title;
    private String author;
    private int pages;

    @ManyToOne
    private Lender owner;

    @ManyToOne
    private Lender borrower;

    @Lob
    private String synopsis;
    @Lob
    private Byte[] coverImage;


    /**
     * This method is used to get the image of a file
     * @return image location
     */
    public String getImage()
    {
        // Check if the image is already located in our
        // /images/covers directory
        String location = "/book_covers/" + title + ".jpg";
        if (new ClassPathResource("/static" + location).isFile())
        {
            return location;
        }

        // if not expect that the book cover was uploaded
        return "/books/" + isbn + "/image";
    }
}
