/*
  Author: Vadim Balan
  Date: 4/21/2021
  Version: 1.0 This is the BookController that is in charge of the mapping for the books and books all page
 */
package edu.greenriver.sdev.booklending.controllers;

import edu.greenriver.sdev.booklending.model.Book;
import edu.greenriver.sdev.booklending.model.Lender;
import edu.greenriver.sdev.booklending.services.BookService;
import edu.greenriver.sdev.booklending.services.LenderService;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

@Controller
@RequestMapping("/books")
public class BookController extends AuthenticationInformation
{
    private final BookService service;
    private final LenderService service_for_lender;

    /**
     * This is the constructor for the book controller
     * @param service creates the book service
     */
    public BookController(BookService service, LenderService service_for_lender)
    {
        this.service = service;
        this.service_for_lender = service_for_lender;
    }

    /**
     * This returns a html file of all the books
     * @param model this is used to add things to the model so it can be displayed on the html file
     * @return the all books which is a html file of all the books
     */
    @GetMapping("/all")
    public String allBooks(Model model)
    {
        model.addAttribute("books", service.getBooks());
        return "books/all_books";
    }

    /**
     * This searches a book by the ISBN
     * @param isbn this is a string because it has dashes and a weird format
     * @param model this is used to add things to the model so it can be displayed on the html file
     * @return it returns a individual page of the book based on the isbn
     */
    @GetMapping("/isbn/{isbn}")
    public String bookByISBN(@PathVariable String isbn, Model model)
    {
        model.addAttribute("books", service.getBook(isbn));
        return "books/view_individual_page";
    }

    /**
     * This is to add a new book to the page
     * @param model this is used to get stuff to the html page
     * @return this returns the add_book html file, form to add a book
     */
    @GetMapping("/add")
    public String addBook(Model model)
    {
        model.addAttribute("book", new Book());
        return "/general/add_book";
    }

    /**
     * This is where the data posts
     * @param book This is the book class that is used
     * @param file file is used to save the image file
     * @param model this is used to get stuff to the html page
     * @return this returns either all the books or back to the page if the isbn exists
     * @throws IOException if the file is wrong
     */
    @PostMapping("/add")
    public String addBook(@ModelAttribute Book book,
                          @RequestParam("cover-image") MultipartFile file, Model model) throws IOException
    {

        if (service.saveBook(book, service_for_lender.getLoggedInUser(), file))
        {
            service.addNewBook(book);
            return "redirect:/books/all";
        }
        else
        {
            model.addAttribute("errors", "ISBN already exists!");
            return "/general/add_book";
        }
    }

    /**
     * This is how to get the image
     * @param isbn this is used to search up an image based on isbn
     * @param response this is used for the iamge file
     * @throws IOException if the file is wrong
     */
    @GetMapping("/{isbn}/image")
    public void bookImage(@PathVariable String isbn, HttpServletResponse response) throws IOException
    {
        // Get our book and cover image
        Book book = service.getBook(isbn);
        Byte[] bytes = book.getCoverImage();

        // Convert the binary data to a byte[] array
        byte[] fileBytes = new byte[bytes.length];
        for(int i = 0; i < bytes.length; i++)
        {
            fileBytes[i] = bytes[i];
        }

        // Send the binary data out to the browser as a jpg image
        response.setContentType("image/jpeg");

        InputStream io = new ByteArrayInputStream(fileBytes);
        IOUtils.copy(io, response.getOutputStream());
    }

    @GetMapping("/borrow/{isbn}")
    public String borrowBook(@PathVariable String isbn)
    {
        Lender loggedInUser = service_for_lender.getLoggedInUser();
        Book book = service.getBook(isbn);

        //borrow the book and save the entities
        service_for_lender.borrowBook(loggedInUser, book);

        return "redirect:/lenders/username/" + book.getOwner().getUsername();
    }
}
