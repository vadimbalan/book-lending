package edu.greenriver.sdev.booklending;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookLendingApplicationTests
{

    @Test
    void contextLoads()
    {
    }

}
